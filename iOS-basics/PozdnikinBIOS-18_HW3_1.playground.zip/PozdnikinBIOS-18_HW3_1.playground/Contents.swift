// задача 1
print("----Задача 1----")
var arrBoy = ["Иван","Петр"]
var arrGirl = ["Мила","Елена","Лада"]
var students = arrGirl

//students.insert(contentsOf: arrBoy, at: 0)
for i in arrBoy.reversed() {
    students.insert(i, at: students.startIndex)
}
print(students)

print("----Задача 2----")
//students.sorted()
//students.sort(by: {$1<$0})
students.sort()
print(students)

print("----Задача 3----")

var A = [-1,4,-3,5,-2,-5]
A.sort(by: {$1<$0})
print(A)
let pozitiveFeedback = A.filter({$0>0})
print(pozitiveFeedback)
/*var z:[Int] = []
for i in A{
    if i>=0 {
    z.append(i)
    }
}
print(z)*/

print("----Задача 4----")

var ar = [1,2,3,4,7,8,15]

var indexA:[Int] = [] // переменная для записи индексов в сумме дающих 6

/*for (index ,value1) in ar.enumerated(){
    for value2 in ar{
        if value1+value2 == 6{
        indexA.append(index)
        }
    }
}
print(indexA)*/

for (index ,value1) in ar.enumerated(){
    ar.forEach({
        if ($0+value1) == 6{
        indexA.append(index)
        }
    })
}
print(indexA)
