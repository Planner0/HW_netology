// задача 1-1
var animalOne:String? = "monkey"
var animalTwo:String? = "elephant"
var animalThree:String? = nil
print("\(animalOne ?? "Клетка пуста")\n\(animalTwo ?? "Клетка пуста")\n\(animalThree ?? "Клетка пуста")")
animalThree = "snake"
print("\(animalOne ?? "Клетка пуста")\n\(animalTwo ?? "Клетка пуста")\n\(animalThree ?? "Клетка пуста")")

//задача 1-2
let one:String = "1"
let two:String = "2"
let three:String = "3"
let four:String = "4four"
let five:String = "5five"

//optional binding
if let oneInt = Int(one),let twoInt = Int(two), let threeInt = Int(three),let fourInt = Int(four), let fiveInt = Int(five){
    print(oneInt+twoInt+threeInt+fourInt+fiveInt)
} else {
    print ("Error")
}
//forced unwrapping
if Int(one) != nil, Int(two) != nil, Int(three) != nil, Int(four) != nil, Int(five) != nil{
    print(Int(one)!+Int(two)!+Int(three)!+Int(four)!+Int(five)!)
} else{
    print("Error")
}
//задача 2
let t: Int? = Int("-5")
if t != nil && t!>=0 && t!<10{
   print ("Выходим из зимней спячки")
} else if t != nil && t!<0 && t!>=(-10){
    print("Зима близко")
} else if t != nil && t!<(-10){
    print ("Надеваем валенки")
}  else if t != nil && t!>=10 {
    print("Готовим плавки")
} else{
    print("Мы в параллельной реальности")
}

switch t {
case (0..<10)?:
    print("Выходим из зимней спячки")
case ((-10)..<0)?:
    print("Зима близко")
case (..<(-10))?:
    print("Надеваем валенки")
case (10...)?:
    print("Готовим плавки")
default:
    print("Мы в параллельной реальности")
}
