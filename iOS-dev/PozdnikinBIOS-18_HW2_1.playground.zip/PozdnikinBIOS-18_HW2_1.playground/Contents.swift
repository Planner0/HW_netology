/*Задача 1
Представьте себя инженером проектировщиком телевизоров во времена, когда эпоха телевещания только набирала обороты. Вам поступила задача создать устройство для просмотра эфира в домашних условиях "Телевизор в каждую семью".

Вам нужно реализовать перечисление "Телевизионный канал" с 5-7 каналами.

Алгоритм выполнения */
print("---задача 1---")
protocol TelevisionBase {
    var name:(Firm:String,Model:String) { get set}
    var power:Bool { get set}
    func powerOnOff()
    func changeChanal(number numChanal:Int)
}

class Television:TelevisionBase {
    //Реализуйте класс "Телевизор". У него должны быть состояния:
    var name:(Firm:String,Model:String) //фирма/модель (реализовать одним полем);
    var power:Bool //включен/выключен;
    var currentChanal:Int //текущий телеканал;
    enum Chanal:Int {
        case Discovery=1,AnimalPlanet,History,Пятница,ТНТ
    }
    init(name:(Firm:String,Model:String),power:Bool,currentChanal:Int){
        self.name = name
        self.power = power
        self.currentChanal=currentChanal
    }
//У него должно быть поведение:
//показать, что сейчас по телеку
    func whatShow(){
        if let chanal = Chanal.init(rawValue: self.currentChanal){
        print("Вы смотрите \(chanal)")
        } else {
        print("No chanal")
        }
    }
    func powerOnOff(){//- Сделайте изменение состояний телевизора (на свой выбор).
        self.power = !self.power
        self.power==true ? print("Телевизор включен") : print("Телевизор выключен")
    }
    func changeChanal(number numChanal:Int){  //переключение каналов
        self.currentChanal = numChanal
        if let chanal = Chanal.init(rawValue: numChanal){
        print("Вы переключились на \(chanal)")
        } else {
        print("No chanal")
        }
    }
    enum Input{
        case video(FilmVHS:String)
        case Tv
    }
    var input:Input = .video(FilmVHS: "Рембо")
    func currentInput(){
        switch input{
        case .video(FilmVHS: let FilmVHS):
            //self.input = .video(FilmVHS:FilmVHS)
            print("Вы смотрите \(FilmVHS)")
        case .Tv:
            //self.input = .Tv
            if let chanal = Chanal.init(rawValue: self.currentChanal){
            print("Вы смотрите \(chanal)")
            } else {
            print("No chanal")
            }
        }
    }
    func changeInput(){
        switch input{
        case .video(FilmVHS: _):
            self.input = .Tv
            print("Вы переключилсь на телевидение")
        case .Tv:
            self.input = .video(FilmVHS:"Рембо")
            print("Вы переключилсь на видеомагнитофон")
        }
    }
}
var tv = Television(name: (Firm: "LG", Model: "OLED55C1RLA"), power: true, currentChanal: 1)
//- Вызовите метод и покажите, что сейчас по телеку.
tv.whatShow()
tv.currentChanal
tv.powerOnOff()
tv.name.Model
tv.power
tv.powerOnOff()
tv.whatShow()
tv.changeChanal(number: 3)
tv.currentChanal
tv.whatShow() //- Повторите вызов метода и покажите, что сейчас по телеку.

/*Задача 2
 Время идет, рынок и потребители развиваются, и ваша компания набирает ритм. Поступают все новые и новые требования к эволюции устройств. Перед вами снова инженерная задача — обеспечить пользователей практичным устройством.

 Алгоритм выполнения
 -Создайте новый класс Телевизор (с другим названием класса), который будет уметь все, что и предыдущий.

 -Реализуйте структуру настроек:

 громкость от 0 до 1 (подумайте, какой тип использовать); показывать цветом или черно-белым (подумайте, какой тип данных лучше всего использовать).

 -Интегрируйте Настройки в новый класс Телевизор.

 Вызовите метод и покажите, что сейчас идет по телевизору, учитывая настройки.*/
print("---задача 2---")
class TelevisionNextGen:Television{
    var volume:Double = 0 {
        didSet{
            if self.volume < 0{
                self.volume = 0
                print("Mute")
            } else if self.volume > 1{
                self.volume = 1
                print("Достигнут предел громкости")
            }
        }
    }
    var color:Bool = false
    /*init(volume:Double,color:Bool){
        self.volume = volume
        self.color = color
        super.init(name: (Firm: "Sumsung", Model: "ttt"), power: true, currentChanal: 1)
    }*/
    func changeVolumeUP(){
        self.volume += 0.1
        print("Уровень громкости установлен на \(self.volume)")
    }
    func changeVolumeDown(){
        self.volume -= 0.1
        print("Уровень громкости установлен на \(self.volume)")
    }
    func changeColor(){
        self.color = !self.color
        self.color==true ? print("Цветной режим") : print("Черно-белый режим")
    }
}
let tvNextGen = TelevisionNextGen(name: (Firm: "Sumsung", Model: "3000"), power: true, currentChanal: 5)
tvNextGen.volume
tvNextGen.color
tvNextGen.changeVolumeDown()
tvNextGen.changeVolumeUP()
tvNextGen.changeVolumeDown()
tvNextGen.changeColor()
tvNextGen.changeColor()
tvNextGen.whatShow()
print("---задача 3*---")
/*Задача 3 * (задача со звездочкой):
 Порог новой эры пройден. Теперь не только есть радиоволна, но и видеомагнитофоны. Эту технику подключают проводами к телевизору и смотрят в записи свои любимые фильмы. Вам, как ведущему инженеру, срочно нужно адаптировать продукт вашей компании, потому как спрос на устаревший вариант резко пошел вниз.

 Алгоритм выполнения
 -Создайте перечисление со связанными значениями с двумя кейсами: телеканал и подключение по входящему видео порту;
 -Интегрируйте эту опцию в Телевизор.
 -Вызовите метод и покажите, что сейчас по телевизору.*/
var tvVHS = Television(name: (Firm: "Akai", Model: "SuperVHS"), power: false, currentChanal: 2)
tvVHS.input
tvVHS.currentInput()
tvVHS.changeInput()
tvVHS.currentInput()
tvVHS.changeInput()
tvVHS.currentInput()

